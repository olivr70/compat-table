// ES6 compatibility checks
// -------------------------
var unableMsg = 'Unable to run this test';
function f(b){try{return new Function(b)} catch(e){return function(){return e;}}}
function a(b){return function() { return new Error(unableMsg)}}
module.exports = {
  "es7": { // group

    finished: {

    "Array.prototype.includes":f("return[1,2,3].includes(1)&&![1,2,3].includes(4)&&![1,2,3].includes(1,1)&&[NaN].includes(NaN)&&Array(1).includes()")
    },
    candidate: {

      "exponentiation (**) operator": { // test
        "basic support":f("\n        return 2 ** 3 === 8 && -(5 ** 2) === -25 && (-5) ** 2 === 25;\n      "),
        "assignment":f("\n        var a = 2; a **= 3; return a === 8;\n      "),
        "early syntax error for unary negation without parens":f("\n        if (2 ** 3 !== 8) { return false; }\n        try {\n          Function(\"-5 ** 2\")();\n        } catch(e) {\n          return true;\n        }\n      ")
      },
    "Object.values":f("var a=Object.create({a:\"qux\",d:\"qux\"});a.a=\"foo\",a.b=\"bar\",a.c=\"baz\";var r=Object.values(a);return Array.isArray(r)&&\"foo,bar,baz\"===String(r)"),
    "Object.entries":f("var r=Object.create({a:\"qux\",d:\"qux\"});r.a=\"foo\",r.b=\"bar\",r.c=\"baz\";var a=Object.entries(r);return Array.isArray(a)&&3===a.length&&\"a,foo\"===String(a[0])&&\"b,bar\"===String(a[1])&&\"c,baz\"===String(a[2])"),
      "trailing commas in function syntax": { // test
        "in parameter lists":f("\n        return typeof function f( a, b, ){} === 'function';\n      "),
        "in argument lists":f("\n        return Math.min(1,2,3,) === 1;\n      ")
      },
      "async functions": { // test
        "basic support":f("\n        return (async function(){\n          return 42;\n        })() instanceof Promise\n      "),
        "await support":f("\n        return (async function(){\n          return 10 + await Promise.resolve(10);\n        })() instanceof Promise\n      "),
        "arrow async functions":f("\n        return (async () => 42 + await Promise.resolve(42))() instanceof Promise\n      ")
      },
      "SIMD (Single Instruction, Multiple Data)": { // test
        "basic support":f("return\"undefined\"!=typeof SIMD"),
        "Float32x4":f("return\"function\"==typeof SIMD.Float32x4"),
        "Float64x2":f("return\"function\"==typeof SIMD.Float64x2"),
        "Int32x4":f("return\"function\"==typeof SIMD.Int32x4"),
        "Int16x8":f("return\"function\"==typeof SIMD.Int16x8"),
        "Int8x16":f("return\"function\"==typeof SIMD.Int8x16"),
        "Bool32x4":f("return\"function\"==typeof SIMD.Bool32x4"),
        "Bool16x8":f("return\"function\"==typeof SIMD.Bool16x8"),
        "Bool8x16":f("return\"function\"==typeof SIMD.Bool8x16"),
        "SIMD.%type%.abs":f("return\"function\"==typeof SIMD.Float32x4.abs"),
        "SIMD.%type%.add":f("return\"function\"==typeof SIMD.Float32x4.add"),
        "SIMD.%integerType%.addSaturate":f("return\"function\"==typeof SIMD.Int16x8.addSaturate"),
        "SIMD.%booleanType%.and":f("return\"function\"==typeof SIMD.Bool16x8.and"),
        "SIMD.%booleanType%.anyTrue":f("return\"function\"==typeof SIMD.Bool32x4.anyTrue"),
        "SIMD.%booleanType%.allTrue":f("return\"function\"==typeof SIMD.Bool32x4.allTrue"),
        "SIMD.%type%.check":f("return\"function\"==typeof SIMD.Float32x4.check"),
        "SIMD.%type%.equal":f("return\"function\"==typeof SIMD.Float32x4.equal"),
        "SIMD.%type%.extractLane":f("return\"function\"==typeof SIMD.Float32x4.extractLane"),
        "SIMD.%type%.greaterThan":f("return\"function\"==typeof SIMD.Float32x4.greaterThan"),
        "SIMD.%type%.greaterThanOrEqual":f("return\"function\"==typeof SIMD.Float32x4.greaterThanOrEqual"),
        "SIMD.%type%.lessThan":f("return\"function\"==typeof SIMD.Float32x4.lessThan"),
        "SIMD.%type%.lessThanOrEqual":f("return\"function\"==typeof SIMD.Float32x4.lessThanOrEqual"),
        "SIMD.%type%.mul":f("return\"function\"==typeof SIMD.Float32x4.mul"),
        "SIMD.%type%.div":f("return\"function\"==typeof SIMD.Float32x4.div"),
        "SIMD.%type%.max":f("return\"function\"==typeof SIMD.Float32x4.max"),
        "SIMD.%type%.maxNum":f("return\"function\"==typeof SIMD.Float32x4.maxNum"),
        "SIMD.%type%.min":f("return\"function\"==typeof SIMD.Float32x4.min"),
        "SIMD.%type%.minNum":f("return\"function\"==typeof SIMD.Float32x4.minNum"),
        "SIMD.%type%.neg":f("return\"function\"==typeof SIMD.Float32x4.neg"),
        "SIMD.%booleanType%.not":f("return\"function\"==typeof SIMD.Bool16x8.not"),
        "SIMD.%type%.notEqual":f("return\"function\"==typeof SIMD.Float32x4.notEqual"),
        "SIMD.%type%.reciprocalApproximation":f("return\"function\"==typeof SIMD.Float32x4.reciprocalApproximation"),
        "SIMD.%type%.reciprocalSqrtApproximation":f("return\"function\"==typeof SIMD.Float32x4.reciprocalSqrtApproximation"),
        "SIMD.%type%.replaceLane":f("return\"function\"==typeof SIMD.Float32x4.replaceLane"),
        "SIMD.%type%.select":f("return\"function\"==typeof SIMD.Float32x4.select"),
        "SIMD.%integerType%.selectBits":f("return\"function\"==typeof SIMD.Int16x8.selectBits"),
        "SIMD.%integerType%.shiftLeftByScalar":f("return\"function\"==typeof SIMD.Int32x4.shiftLeftByScalar"),
        "SIMD.%integerType%.shiftRightLogicalByScalar":f("return\"function\"==typeof SIMD.Int32x4.shiftRightLogicalByScalar"),
        "SIMD.%integerType%.shiftRightArithmeticByScalar":f("return\"function\"==typeof SIMD.Int32x4.shiftRightArithmeticByScalar"),
        "SIMD.%type%.shuffle":f("return\"function\"==typeof SIMD.Float32x4.shuffle"),
        "SIMD.%type%.splat":f("return\"function\"==typeof SIMD.Float32x4.splat"),
        "SIMD.%type%.sqrt":f("return\"function\"==typeof SIMD.Float32x4.sqrt"),
        "SIMD.%type%.store":f("return\"function\"==typeof SIMD.Float32x4.store"),
        "SIMD.%type%.store1":f("return\"function\"==typeof SIMD.Float32x4.store1"),
        "SIMD.%type%.store2":f("return\"function\"==typeof SIMD.Float32x4.store1"),
        "SIMD.%type%.store3":f("return\"function\"==typeof SIMD.Float32x4.store1"),
        "SIMD.%type%.sub":f("return\"function\"==typeof SIMD.Float32x4.sub"),
        "SIMD.%integerType%.subSaturate":f("return\"function\"==typeof SIMD.Int16x8.subSaturate"),
        "SIMD.%type%.swizzle":f("return\"function\"==typeof SIMD.Float32x4.swizzle"),
        "SIMD.%booleanType%.xor":f("return\"function\"==typeof SIMD.Bool16x8.xor")
      },
      "String padding": { // test
        "String.prototype.padStart":f("return\"     hello\"===\"hello\".padStart(10)&&\"12341hello\"===\"hello\".padStart(10,\"1234\")&&\"hello\"===\"hello\".padStart()&&\"1hello\"===\"hello\".padStart(6,\"123\")"),
        "String.prototype.padEnd":f("return\"hello     \"===\"hello\".padEnd(10)&&\"hello12341\"===\"hello\".padEnd(10,\"1234\")&&\"hello\"===\"hello\".padEnd()&&\"hello1\"===\"hello\".padEnd(6,\"123\")")
      }
    },
    draft: {

    "function.sent":f("\n    var result;\n    function* generator() {\n      result = function.sent;\n    }\n    var iter = generator();\n    iter.next('tromple');\n    return result === 'tromple';\n  "),
    "Object.observe":a("var e={x:1};Object.observe(e,function(e){var a=e[0];\"x\"===a.name&&\"update\"===a.type&&1===a.oldValue&&2===a.object.x&&asyncTestPassed()}),e.x=2"),
    "object rest properties":f("\n    var {a, ...rest} = {a: 1, b: 2, c: 3};\n    return a === 1 && rest.a === undefined && rest.b === 2 && rest.c === 3;\n  "),
    "object spread properties":f("\n    var spread = {b: 2, c: 3};\n    var O = {a: 1, ...spread};\n    return O.a + O.b + O.c === 6;\n  ")
    },
    proposal: {

    "ArrayBuffer.transfer":f("return\"function\"==typeof ArrayBuffer.transfer"),
    "class decorators":f("\n    class A {\n      @nonconf\n      get B() {}\n    }\n    function nonconf(target, name, descriptor) {\n      descriptor.configurable = false;\n      return descriptor;\n    }\n    return Object.getOwnPropertyDescriptor(A.prototype, \"B\").configurable === false;\n  "),
    "class properties":f("\n    class C {\n      x = 'x';\n      static y = 'y';\n    }\n    return new C().x + C.y === 'xy';\n  "),
    "call constructor":f("\n    class C {\n      constructor(){\n        this.x = 'x';\n      }\n      call constructor(){\n        return 'y';\n      }\n    }\n    return new C().x + C() === 'xy';\n  "),
      "String trimming": { // test
        "String.prototype.trimLeft":f("return\"abc   \t\\n\"===\" \t \\n abc   \t\\n\".trimLeft()"),
        "String.prototype.trimRight":f("return\" \t \\n abc\"===\" \t \\n abc   \t\\n\".trimRight()")
      }
    },
    strawman: {

      "bind (::) operator": { // test
        "binary form":f("\n        function foo() { this.garply += \"foo\"; return this; }\n        var obj = { garply: \"bar\" };\n        return typeof obj::foo === \"function\" && obj::foo().garply === \"barfoo\";\n      "),
        "unary form":f("\n        var obj = { garply: \"bar\", foo: function() { this.garply += \"foo\"; return this; } };\n        return typeof ::obj.foo === \"function\" && ::obj.foo().garply === \"barfoo\";\n      ")
      },
    "do expression":f("\n    return do {\n      let x = 23;\n      x + 19;\n    } === 42;\n  "),
    "Object.getOwnPropertyDescriptors":f("var e={a:1},a=\"function\"==typeof Symbol?Symbol(\"b\"):\"b\";e[a]=2;var r=Object.defineProperty(e,\"c\",{value:3}),b=Object.getOwnPropertyDescriptors(r);return 1===b.a.value&&b.a.enumerable===!0&&b.a.configurable===!0&&b.a.writable===!0&&2===b[a].value&&b[a].enumerable===!0&&b[a].configurable===!0&&b[a].writable===!0&&3===b.c.value&&b.c.enumerable===!1&&b.c.configurable===!1&&b.c.writable===!1"),
    "Map.prototype.toJSON":f("var n=new Map;return n.set(\"a\",\"b\"),n.set(\"c\",\"d\"),'[[\"a\",\"b\"],[\"c\",\"d\"]]'===JSON.stringify(n)"),
    "Set.prototype.toJSON":f("var n=new Set;return[1,2,3,2,1].forEach(function(r){n.add(r)}),\"[1,2,3]\"===JSON.stringify(n)"),
    "String.prototype.at":f("return\"𠮷\"===\"a𠮷b\".at(1)")
    },
    pre-strawman: {

    "array comprehensions":f("\n    return [for (a of [1, 2, 3]) a * a] + '' === '1,4,9';\n  "),
    "generator comprehensions":f("\n    var iterator = (for (a of [1,2]) a + 4);\n    var item = iterator.next();\n    var passed = item.value === 5 && item.done === false;\n    item = iterator.next();\n    passed    &= item.value === 6 && item.done === false;\n    item = iterator.next();\n    passed    &= item.value === undefined && item.done === true;\n    return passed;\n  "),
    "destructuring in comprehensions":f("\n    return [for([a, b] of [['a', 'b']])a + b][0] === 'ab';\n  "),
    "Reflect.Realm":f("var e,t=[\"eval\",\"global\",\"intrinsics\",\"stdlib\",\"directEval\",\"indirectEval\",\"initGlobal\",\"nonEval\"];if(\"object\"!=typeof Reflect||\"function\"!=typeof Reflect.Realm||\"object\"!=typeof Reflect.Realm.prototype)return!1;for(e=0;e<t.length;e++)if(!(t[e]in Reflect.Realm.prototype))return!1;return!0"),
    "RegExp.escape":f("return\"Hello, \\\\\\\\\\\\^\\\\$\\\\*\\\\+\\\\?\\\\.\\\\(\\\\)\\\\|\\\\[\\\\]\\\\{\\\\}!\"===RegExp.escape(\"Hello, \\\\^$*+?.()|[]{}!\")")
    },
    errata: {

    "generator functions can't be used with \"new\"":f("\n    function * generator() {\n      yield 3;\n    }\n    try {\n      new generator();\n    } catch(e) {\n      return true;\n    }\n  "),
    "strict fn w/ non-strict non-simple params is error":f("\n    function foo(...a){}\n    try {\n      Function(\"function bar(...a){'use strict';}\")();\n    } catch(e) {\n      return true;\n    }\n  "),
    "nested rest destructuring":f("\n    var [x, ...[y, ...z]] = [1,2,3,4];\n    return x === 1 && y === 2 && z + '' === '3,4';\n  ")
    }
  }};
