// ES6 compatibility checks
// -------------------------
var unableMsg = 'Unable to run this test';
function f(b){try{return new Function(b)} catch(e){return function(){return e;}}}
function a(b){return function() { return new Error(unableMsg)}}
module.exports = {
  es5: {

  "Object.create":f("return\"function\"==typeof Object.create"),
  "Object.defineProperty":f("return\"function\"==typeof Object.defineProperty"),
  "Object.defineProperties":f("return\"function\"==typeof Object.defineProperties"),
  "Object.getPrototypeOf":f("return\"function\"==typeof Object.getPrototypeOf"),
  "Object.keys":f("return\"function\"==typeof Object.keys"),
  "Object.seal":f("return\"function\"==typeof Object.seal"),
  "Object.freeze":f("return\"function\"==typeof Object.freeze"),
  "Object.preventExtensions":f("return\"function\"==typeof Object.preventExtensions"),
  "Object.isSealed":f("return\"function\"==typeof Object.isSealed"),
  "Object.isFrozen":f("return\"function\"==typeof Object.isFrozen"),
  "Object.isExtensible":f("return\"function\"==typeof Object.isExtensible"),
  "Object.getOwnPropertyDescriptor":f("return\"function\"==typeof Object.getOwnPropertyDescriptor"),
  "Object.getOwnPropertyNames":f("return\"function\"==typeof Object.getOwnPropertyNames"),
  "Date.prototype.toISOString":f("return\"function\"==typeof Date.prototype.toISOString"),
  "Date.now":f("return\"function\"==typeof Date.now"),
  "Date.prototype.toJSON":f("try{return null===Date.prototype.toJSON.call(new Date(NaN))}catch(t){return!1}"),
  "Date.parse on invalid dates":f("var a=!isNaN(Date.parse(\"2012-04-04T24:00:00.500Z\")),e=!isNaN(Date.parse(\"2012-12-31T24:01:00.000Z\")),r=!isNaN(Date.parse(\"2011-02-29T12:00:00.000Z\"));return!a&&!e&&!r"),
  "Array.isArray":f("return\"function\"==typeof Array.isArray"),
  "JSON":f("return\"object\"==typeof JSON"),
  "Function.prototype.bind":f("return\"function\"==typeof Function.prototype.bind"),
  "String.prototype.trim":f("return\"function\"==typeof String.prototype.trim"),
  "Array.prototype.indexOf":f("return\"function\"==typeof Array.prototype.indexOf"),
  "Array.prototype.lastIndexOf":f("return\"function\"==typeof Array.prototype.lastIndexOf"),
  "Array.prototype.every":f("return\"function\"==typeof Array.prototype.every"),
  "Array.prototype.some":f("return\"function\"==typeof Array.prototype.some"),
  "Array.prototype.forEach":f("return\"function\"==typeof Array.prototype.forEach"),
  "Array.prototype.map":f("return\"function\"==typeof Array.prototype.map"),
  "Array.prototype.filter":f("return\"function\"==typeof Array.prototype.filter"),
  "Array.prototype.reduce":f("return\"function\"==typeof Array.prototype.reduce"),
  "Array.prototype.reduceRight":f("return\"function\"==typeof Array.prototype.reduceRight"),
  "Getter in property initializer":f("return 1==={get x(){return 1}}.x"),
  "Setter in property initializer":f("var t=0;return{set x(n){t=n}}.x=1,1===t"),
  "Property access on strings":f("return\"b\"===\"foobar\"[3]"),
  "Reserved words as property names":f("return 1==={\"if\":1}[\"if\"]"),
  "Zero-width chars in identifiers":f("var n=!0;return n"),
  "parseInt() ignores leading zeros":f("return 10===parseInt(\"010\")"),
  "Immutable undefined":f("undefined=12345;var n=!0;return undefined=void 0,n"),
  "Strict mode":f("\"use strict\";return!this")
  }};
